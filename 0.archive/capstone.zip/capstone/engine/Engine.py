from baynet.bayesian_model import model_run
import json

class read_json():
    def __init__(self):
        # self.path = '/Users/zy/Desktop/capstone 2/conversation.json'  # Yao
        self.path = 'E:/px/UChi/Courses/Capstone/code/capstone/engine/conversation.json'  # Oscar
        self.data = None

        # Inputs from conversation
        self.mkt_ticker = 'SP'
        self.indicators_node_list = []
        self.client_portfolio = 'Mid_Core'
        self.input_nodes = []

        # Our default inputs for BN and results
        self.oil_jump = 0.3
        self.crash_ = -0.1
        self.portfolio_loss = -0.05
        self.simulate_samples_number = 10000
        self.historical_time_horizon = 2
        self.diff_periods = 1
        self.returns_roll_window = 5

    def read_(self):
        with open(self.path, 'r') as file:
            self.data = json.load(file)

        self.filter_empty_keys()

    def filter_empty_keys(self):
        keys_to_check = ['control', 'mkt_cap', 'mitigators', 'triggers', 'events', 'edges', 'consequences', 'style', 'sectors']
        for key in keys_to_check:
            value = self.data.get(key)
            if value is not None:
                setattr(self, key, value)


class Engine(read_json):
    def __init__(self):
        super().__init__()
        self.read_()

    def read_(self):
        super().read_()
        self.mkt_ticker = (self.data.get('mkt_cap'))
        self.indicators_node_list = (self.data.get('sectors'))
        self.client_portfolio = (self.data.get('style'))
        self.input_nodes = (self.data.get('edges'))

    def start(self):
        self.BN_model = model_run(self.mkt_ticker, self.client_portfolio, self.input_nodes, self.crash_, self.portfolio_loss,
                                  self.oil_jump, self.diff_periods,  self.historical_time_horizon, self.returns_roll_window)
        self.BN_model.run_BN_model()

