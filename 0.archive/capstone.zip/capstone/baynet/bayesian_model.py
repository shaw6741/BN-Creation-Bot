import numpy as np
import pandas as pd
import copy
import datetime
import random
from utils.utils import get_data, definition_BayesianNetwork


class model_run(definition_BayesianNetwork):
    def __init__(self, mkt_ticker, client_portfolio, nodes, crash, portfolio_loss, oil_jump, diff_periods, time_horizon, roll_win):
        self.mkt_ticker = mkt_ticker
        self.client_portfolio = client_portfolio
        self.nodes = nodes
        self.crash_ = crash
        self.portfolio_loss = portfolio_loss
        self.oil_jump = oil_jump
        self.diff_periods = diff_periods
        self.time_horizon = time_horizon
        self.roll_win = roll_win
        self.data_pull = get_data()
        self.start, self.end = self.data_pull.get_start_end_dates(self.time_horizon)
        # self.run()  # This could be a button

    def get_indicators_node_list(self):
        self.indicators_node_list = []
        self.missing_node_list = []

        for node_tuple in self.nodes:
            node_list = list(node_tuple)
            for node in node_list:
                if node == 'MC' or node == 'LOSS':
                    next
                elif node in self.data_pull.market_ticker_dict.keys() or node in self.data_pull.economical_ticker_dict.keys():
                    if node not in self.indicators_node_list:
                        self.indicators_node_list.append(node)
                else:
                    if node not in self.missing_node_list:
                        self.missing_node_list.append(node)

    def construct_mkt_crash(self):
        # If we assume always need mkt data this step is necessary
        mkt_close = self.data_pull.get_historical_data(self.mkt_ticker, self.start, self.end)
        mkt_ret, mkt_roll_ret = self.data_pull.get_rolling_returns(mkt_close, self.diff_periods, self.roll_win)

        # if MC always comes from mkt returns this step is necessary
        self.mc = self.data_pull.get_mc_correction(mkt_roll_ret, self.crash_)

    def construct_portfolio_loss(self, port_ind='LOSS'):
        # If portfolio provided
        port_close = self.data_pull.get_df_portfolio(self.client_portfolio, self.start, self.end)

        # customer might determine their loss
        port_ret, port_roll_ret = self.data_pull.get_rolling_returns(port_close, self.diff_periods, self.roll_win)
        self.port = self.data_pull.get_mc_correction(port_roll_ret, self.portfolio_loss, port_ind)

    def merge_df(self):
        self.merged_data = pd.merge(self.mc, self.eco_data, how='left', left_index=True, right_index=True)
        self.merged_data.fillna(method='ffill', inplace=True)
        self.merged_data.dropna(inplace=True)

        self.merged_data = pd.merge(self.merged_data, self.port, how='left', left_index=True, right_index=True)
        self.merged_data.fillna(method='ffill', inplace=True)
        self.merged_data.dropna(inplace=True)

    def generate_bin_data(self):
        self.bn_data = copy.deepcopy(self.merged_data)

        for ind in self.indicators_node_list:
            if ind == 'OIL':
                self.bn_data[ind] = self.bn_data[ind] >= self.oil_jump
            else:
                self.bn_data[ind] = self.bn_data[ind] >= 0
            self.bn_data[ind] = self.bn_data[ind].astype(int)

    def get_rnd(self, n, pct_0=60):
        random_array = np.random.choice([0, 1], size=n, p=[pct_0 / 100, (100 - pct_0) / 100])
        return random_array

    def generate_random_data(self):
        # get some random date for other parameters
        N = len(self.bn_data)
        for col_name in self.missing_node_list:
            rand_num = random.randint(50, 99)
            temp_array = self.get_rnd(N, rand_num)
            self.bn_data[col_name] = temp_array

    def initialized_data(self):
        self.eco_data = pd.DataFrame()
        for ind in self.indicators_node_list:
            ind_data = self.data_pull.get_historical_data(ind, self.start, self.end)
            ind_ret, int_rolling_change = self.data_pull.get_rolling_returns(ind_data, self.diff_periods, self.roll_win)
            self.eco_data = pd.concat([self.eco_data, int_rolling_change], axis=1)
        self.eco_data.columns = self.indicators_node_list

        self.construct_mkt_crash()
        self.construct_portfolio_loss()
        self.merge_df()
        self.generate_bin_data()
        self.generate_random_data()

    def run_BN_model(self):
        self.get_indicators_node_list()
        self.initialized_data()
        self.create_network(self.nodes)
        self.fit_network(self.bn_data)